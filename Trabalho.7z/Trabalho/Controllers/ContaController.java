package Controllers;

import java.util.ArrayList;

import Controllers.contracts.IContaController;
import Models.ContaBancaria;
import Models.Cliente;

public class ContaController implements IContaController {

    private static ArrayList<ContaBancaria> Contas = new ArrayList<ContaBancaria>();
    @Override
    public void cadastrar(ContaBancaria conta) {
                if(buscarPorCpf(cliente.getCpf()) == null){
            contas.add(conta);
            System.out.println("Cliente cadastrado com sucesso!!");
            return true; 
        }
        return false;
     }
    
    @Override
    public Conta buscarPorCpf(String id){
        for (Conta ContaCadastrada : Contas) {
            if(ContaCadastrada.getId().equals(id)){
                return ContaCadastrada;
            }
        }
        return null;
    }   
}