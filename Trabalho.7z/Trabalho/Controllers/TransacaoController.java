package Controllers;

import java.util.ArrayList;

import Models.Transacao;

public class TransacaoController{

    private static ArrayList<Transacao> transacoes = new ArrayList<Transacao>();
    public void cadastrar(Transacao transacao) {
        transacoes.add(transacao);
    }
    public ArrayList<Transacao> listar() {
        return transacoes;
    }
}