package views;

import Utils.Console;

public class PrincipalF2{
    public static void main(String[] args) {

            int opcao = 0;

            do{
                System.out.println("\nBem Vindo a Locadora Fire Stars: escolha uma opção.\n");
                System.out.println("1- Cadastrar Cliente: ");
                System.out.println("2- Listar Clientes: ");
                System.out.println("3- Procurar Clientes: ");
                System.out.println("4- Remover Clientes: ");
                System.out.println("5- Cadastrar Conta Bancária: ");
                System.out.println("6- Cadastrar Transação: ");
                System.out.println("7- Listar Entradas: ");
                System.out.println("8- Listar Retiradas: ");
                System.out.println("0- Sair.");
                opcao = Console.readInt("Digite uma opção: ");
                
                switch(opcao){
                    case 1:
                        CadastrarCliente cadastrarCliente = new CadastrarCliente();
                        cadastrarCliente.renderizar();
                        break;
                    case 2:
                        ListarCliente listarCliente = new ListarCliente();
                        listarCliente.renderizar();
                        break;
                    case 3:
                        ProcurarCliente procurarCliente = new ProcurarCliente();
                        procurarCliente.renderizar();
                        break;
                    case 4:
                        RemoverCliente removerCliente = new RemoverCliente();
                        removerCliente.remover();
                        break;
                    case 5:
                        CadastrarConta cadastrarConta = new CadastrarConta();
                        cadastrarConta.renderizar(); 
                        break;
                    case 6:
                        CadastrarTrans cadastrarTrans = new CadastrarTrans();
                        cadastrarTrans.renderizar(); 
                        break;
                    case 7:
                        ListarEntradas listarEntradas = new ListarEntradas();
                        listarEntradas.renderizar();
                        break;
                    case 8:
                        ListarRetiradas listarRetiradas = new ListarRetiradas();
                        listarRetiradas.renderizar();
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            }while(opcao != 0);
    }
} 