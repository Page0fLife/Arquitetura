package views;

import Utils.Console;

public class PrincipalF1{
    public static void main(String[] args) {

            int opcao = 0;
            //Cliente cliente;
            //Produto produto;
            //Funcionario funcionario;

            do{
                System.out.println("\nBem Vindo a Locadora Fire Stars: escolha uma opção.\n");
                System.out.println("1- Cadastrar Cliente: ");
                System.out.println("2- Listar Clientes: ");
                System.out.println("3- Procurar Clientes: ");
                System.out.println("4- Remover Clientes: ");
                System.out.println("5- Cadastrar Funcionário: ");
                System.out.println("6- Listar Funcionários: ");
                System.out.println("7- Procurar Funcionários: ");
                System.out.println("8- Remover Funcionários: ");
                System.out.println("9- Cadastrar Conta Bancária: ");
                System.out.println("10- Cadastrar Transação: ");
                System.out.println("11- Listar Entradas: ");
                System.out.println("12- Listar Retiradas: ");
                System.out.println("0- Sair.");
                opcao = Console.readInt("Digite uma opção: ");
                
                switch(opcao){
                    case 1:
                        CadastrarCliente cadastrarCliente = new CadastrarCliente();
                        cadastrarCliente.renderizar();
                        break;
                    case 2:
                        ListarCliente listarCliente = new ListarCliente();
                        listarCliente.renderizar();
                        break;
                    case 3:
                        ProcurarCliente procurarCliente = new ProcurarCliente();
                        procurarCliente.renderizar();
                        break;
                    case 4:
                        RemoverCliente removerCliente = new RemoverCliente();
                        removerCliente.remover();
                        break;
                    case 5:
                        CadastrarFuncionario cadastrarFuncionario = new CadastrarFuncionario();
                        cadastrarFuncionario.renderizar();
                    case 6:
                        ListarFuncionario listarFuncionario = new ListarFuncionario();
                        listarFuncionario.renderizar();
                        break;
                    case 7:
                        ProcurarFuncionario procurarFuncionario = new ProcurarFuncionario();
                        procurarFuncionario.renderizar();
                        break;
                    case 8:
                        RemoverFuncionario removerFuncionario = new RemoverFuncionario();
                        removerFuncionario.remover();
                        break;
                    case 9:
                        CadastrarConta cadastrarConta = new CadastrarConta();
                        cadastrarConta.renderizar(); 
                        break;
                    case 10:
                        CadastrarTrans cadastrarTrans = new CadastrarTrans();
                        cadastrarTrans.renderizar(); 
                        break;
                    case 11:
                        ListarEntradas listarEntradas = new ListarEntradas();
                        listarEntradas.renderizar();
                        break;
                    case 12:
                        ListarRetiradas listarRetiradas = new ListarRetiradas();
                        listarRetiradas.renderizar();
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            }while(opcao != 0);
    }
} 