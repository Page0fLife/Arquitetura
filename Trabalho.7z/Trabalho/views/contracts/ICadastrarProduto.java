package views.contracts;

public interface ICadastrarProduto {

    void renderizar();
    
}
