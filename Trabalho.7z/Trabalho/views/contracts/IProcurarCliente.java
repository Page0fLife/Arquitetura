package views.contracts;

public interface IProcurarCliente {
    
    void renderizar();
    
}
