package views.contracts;

public interface ICadastrarCliente {
    
    void renderizar();
}
