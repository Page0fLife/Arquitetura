package views.contracts;

public interface IListarProduto {
    void renderizar();
}
