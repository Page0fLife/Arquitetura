package views;

import Controllers.LocarController;
import Utils.Console;
import views.contracts.IChecagemAluguel;

public class ChecagemAluguel implements IChecagemAluguel{
    
    @Override
    public void renderizar(){
        LocarController locarController = new LocarController();
        locarController.multar(Console.readInt("Quantos dias foram atrasados? "));
    }
}
