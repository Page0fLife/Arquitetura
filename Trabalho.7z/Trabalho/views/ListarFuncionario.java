package views;

import Controllers.FuncionarioController;
import Models.Funcionario;
import views.contracts.IListarFuncionarios;

public class ListarFuncionario implements IListarFuncionarios {
    @Override
    public void renderizar(){
        FuncionarioController funcionarioController = new FuncionarioController();       
        System.out.println("\n -- LISTAGEM DE FUNCIONÁRIOS -- \n");
        for (Funcionario funcionarioCadastrado : funcionarioController.listar()) {
            System.out.println(funcionarioCadastrado);
        }
    }
    
}

