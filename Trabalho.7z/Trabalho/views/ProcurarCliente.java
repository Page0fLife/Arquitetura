package views;

import Controllers.ClienteController;
import Utils.Console;
import views.contracts.IProcurarCliente;

public class ProcurarCliente implements IProcurarCliente {
    @Override
    public void renderizar(){
        
         ClienteController clienteController = new ClienteController();

         clienteController.buscarPorCpf(Console.readString("Digite um cpf: "));
    }
}
