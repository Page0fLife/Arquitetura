package views;

import java.util.Date;
import java.util.Calendar; 
import java.text.DateFormat; 
import java.text.SimpleDateFormat;
import Controllers.LocarController;
import Models.Locacao;
import Utils.Console;
import views.contracts.ICadastrarAluguel;

public class CadastrarAluguel implements ICadastrarAluguel{
    @Override
    public void renderizar(){
        final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Locacao aluguel = new Locacao();
        LocarController alugarController = new LocarController();

        System.out.println("\n CADASTRO DE LOCAÇÃO: ");
        aluguel.setCliente(Console.readString("Digite o nome do Cliente: "));
        aluguel.setProduto(Console.readString("Digite o nome do produto: "));

        alugarController.cadastrar(aluguel);

        Date currentDate = new Date(); 

        Calendar c = Calendar.getInstance(); 
        c.setTime(currentDate); 
        c.add(Calendar.DATE, 7); 
        Date currentDatePlusOne = c.getTime(); 
        
        System.out.println("\n Data de entrega: " + dateFormat.format(currentDatePlusOne)); 

        aluguel.setEntrega(currentDatePlusOne);

        System.out.println("\nLocação registrada !!!");

    }
}
