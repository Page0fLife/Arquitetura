package views;

import Utils.Console;

public class PrincipalC{
    public static void main(String[] args) {

            int opcao = 0;

            do{
                System.out.println("\nBem Vindo a Locadora Fire Stars: escolha uma opção.\n");
                System.out.println("1- Cadastrar Cliente: ");
                System.out.println("2- Remover Clientes: ");
                System.out.println("3- Cadastrar Conta Bancária: ");
                System.out.println("4- Cadastrar Transação: ");
                System.out.println("5- Listar Entradas: ");
                System.out.println("6- Listar Retiradas: ");
                System.out.println("0- Sair.");
                opcao = Console.readInt("Digite uma opção: ");
                
                switch(opcao){
                    case 1:
                        CadastrarCliente cadastrarCliente = new CadastrarCliente();
                        cadastrarCliente.renderizar();
                        break;
                    case 2:
                        RemoverCliente removerCliente = new RemoverCliente();
                        removerCliente.remover();
                        break;
                    case 3:
                        CadastrarConta cadastrarConta = new CadastrarConta();
                        cadastrarConta.renderizar(); 
                        break;
                    case 4:
                        CadastrarTrans cadastrarTrans = new CadastrarTrans();
                        cadastrarTrans.renderizar(); 
                        break;
                    case 5:
                        ListarEntradas listarEntradas = new ListarEntradas();
                        listarEntradas.renderizar();
                        break;
                    case 6:
                        ListarRetiradas listarRetiradas = new ListarRetiradas();
                        listarRetiradas.renderizar();
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            }while(opcao != 0);
    }
} 