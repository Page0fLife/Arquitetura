package views;

import Controllers.ClienteController;
import Models.Cliente;
import Utils.Console;
import Utils.verificacao;
import views.contracts.ICadastrarCliente;

public class CadastrarCliente implements ICadastrarCliente{
    @Override
    public void renderizar(){
        Cliente cliente= new Cliente();
        ClienteController clienteController = new ClienteController();

        System.out.println("\n -- CADASTRO DE CLIENTES -- \n");
        cliente.setNome(Console.readString("Digite o nome do cliente: "));
        cliente.setCpf(Console.readString("Digite o CPF do cliente: "));
        cliente.setTel(Console.readString("Digite o telefone do cliente: "));
        cliente.setEnd(Console.readString("Digite o endereço do cliente: "));
        cliente.setEmail(Console.readString("Digite o email do cliente: "));

        clienteController.cadastrar(cliente);

        if(verificacao.verificarCPF(cliente.getCpf())){
            if(clienteController.cadastrar(cliente)){
                System.out.println("\n Cliente cadastrado com sucesso!!");
            }else{
                System.out.println("\n Cliente já cadastrado!!");
            }
        }else{
            System.out.println("\n Erro no cadastro!!");
            }
        }
}
