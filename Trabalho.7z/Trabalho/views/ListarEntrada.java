package views;

import Controllers.LocarController;
import Models.Locacao;
import views.contracts.IListarLocacao;

public class ListarLocacao implements IListarLocacao{
    @Override
    public void renderizar(){
        LocarController locarController = new LocarController();
        System.out.println("\n --LISTA DE ALUGUEIS-- \n");
        for (Locacao locacaoCadastrado : locarController.listar()) {
            System.out.println(locacaoCadastrado);
        }
    }
}
