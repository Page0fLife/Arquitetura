package Controllers;

import java.util.ArrayList;
import Controllers.contracts.ILoginController;
import Models.Cliente;
import Models.Funcionario;

public class LoginController implements ILoginController{
        @Override
        public boolean logar(String user, String senha){
            for(int i = 0; i<clientes.length; i++){
                if(user.equals(clientes.getCpf[i]) && senha.equals(clientes.getSenha[i])){
                    logado = true;
                }    
                if(user.equals(funcionarios.getId[i]) && senha.equals(funcionarios.getSenha[i])){
                    logado = true;
                }
            }
        }
	}
}