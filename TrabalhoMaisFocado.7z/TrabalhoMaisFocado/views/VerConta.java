package views;

import Controllers.ContaController;
import Models.ContaBancaria;
import views.contracts.IVerConta;

public class VerConta implements IVerConta{
    @Override
    public void renderizar(){
        ProdutoController ContaController = new ContaController();      
        System.out.println("\n -- INFORMAÇÃO DA CONTA BANCÁRIA -- \n");
        for (ContaBancaria ContaCadastrada : ContaController.listar()) {
            System.out.println(ContaCadastrada);
        }
    }
    
}

