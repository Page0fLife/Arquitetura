package views;

import Controllers.loginController;
import Utils.Console;
import views.contracts.ILogin;

public class login implements Ilogin{
    
    @Override
    public void login(){
        LoginController loginController = new LoginController();
        loginController.logar(Console.readString("Digite o CPF ou o ID por favor: "), Console.readString("Digite sua senha: "));
    }
}
