package Models;

public class Funcionario extends ManegeamentoPessoal {

    private String id;
    private String turno;
    private String jorn;
    private String email;
    private String cargo;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getTurno(){
        return turno;
    }
    public void setTurno(String turno){
        this.turno = turno;
    }

    public String getJorn(){
        return jorn;
    }
    public void setJorn(String jorn){
        this.jorn = jorn;
    }

    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }

    public String getCargo(){
        return cargo;
    }
    public void setCargo(String cargo){
        this.cargo = cargo;
    }

    @Override
    public String toString(){
        return "Nome: " + nome + " | CPF: " + cpf + " | Identificação: " + id + " | Turno: " + turno + " | Jornada: " + jorn + " | Email: " + email + " | Cargo: " + cargo;
    }
    public void printDetails() {
    }

    

    
}
